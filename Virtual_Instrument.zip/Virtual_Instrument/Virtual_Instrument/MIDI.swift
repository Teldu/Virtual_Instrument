//
//  MIDI.swift
//  Virtual_Instrument
//
//  Created by Sean on 8/16/19.
//  Copyright © 2019 Sean. All rights reserved.
//

import Foundation
import Cocoa
import AVFoundation
import AudioToolbox
import CoreMIDI

var midiClient: MIDIClientRef = 0
var inPort:MIDIPortRef = 0
var src:MIDIEndpointRef = MIDIGetSource(0)

class midiPlayer{
    func getDisplayName(_ obj: MIDIObjectRef) -> String
    {
        var param: Unmanaged<CFString>?
        var name: String = "Error"
        
        let err: OSStatus = MIDIObjectGetStringProperty(obj, kMIDIPropertyDisplayName, &param)
        if err == OSStatus(noErr)
        {
            name =  param!.takeRetainedValue() as String
        }
        
        return name
    }
    
    func MyMIDIReadProc(pktList: UnsafePointer<MIDIPacketList>,
                        readProcRefCon: UnsafeMutableRawPointer?, srcConnRefCon: UnsafeMutableRawPointer?) -> ()
    {
        let packetList:MIDIPacketList = pktList.pointee
        let srcRef:MIDIEndpointRef = srcConnRefCon!.load(as: MIDIEndpointRef.self)
        
        print("MIDI Received From Source: \(getDisplayName(srcRef))")
        
        var packet:MIDIPacket = packetList.packet
        for _ in 1...packetList.numPackets
        {
            let bytes = Mirror(reflecting: packet.data).children
            var dumpStr = ""
            
            // bytes mirror contains all the zero values in the ridiulous packet data tuple
            // so use the packet length to iterate.
            var i = packet.length
            for (_, attr) in bytes.enumerated()
            {
                dumpStr += String(format:"$%02X ", attr.value as! UInt8)
                i -= 1
                if (i <= 0)
                {
                    break
                }
            }
            
            print(dumpStr)
            packet = MIDIPacketNext(&packet).pointee
        }
    }
    
    let makeMidiClient = MIDIClientCreate("MidiTestClient" as CFString, nil, nil, &midiClient)
    //let midiPort = MIDIInputPortCreate(midiClient, "MidiTest_InPort" as CFString, MyMIDIReadProc, nil, &inPort)
    
    let midiConnectSource = MIDIPortConnectSource(inPort, src, &src)

}
