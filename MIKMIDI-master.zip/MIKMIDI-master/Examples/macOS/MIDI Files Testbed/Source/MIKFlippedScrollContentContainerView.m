//
//  MIKFlippedScrollContentContainerView.m
//  MIDI Files Testbed
//
//  Created by Andrew Madsen on 3/20/15.
//  Copyright (c) 2015 Mixed In Key. All rights reserved.
//

#import "MIKFlippedScrollContentContainerView.h"

@implementation MIKFlippedScrollContentContainerView

- (BOOL)isFlipped { return YES; }

@end
