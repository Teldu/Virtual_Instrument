//
//  main.m
//  MIDI To Audio
//
//  Created by Andrew Madsen on 2/13/15.
//  Copyright (c) 2015-2016 Mixed In Key. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
	return NSApplicationMain(argc, argv);
}
